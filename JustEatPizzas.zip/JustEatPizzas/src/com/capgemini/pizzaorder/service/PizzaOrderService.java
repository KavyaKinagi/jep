package com.capgemini.pizzaorder.service;

import java.sql.SQLException;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.dao.IPizzaOrderDao;
import com.capgemini.pizzaorder.dao.PizzaOrderDao;
import com.capgemini.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService{

	IPizzaOrderDao pizzaRef = new PizzaOrderDao();
	
	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException, SQLException {

		return pizzaRef.placeOrder(customer, pizza);
	}

	@Override
	public Pizza displayOrder(int orderId) throws PizzaException, SQLException {
		
		return pizzaRef.displayOrder(orderId);
	}

	@Override
	public boolean isValidMobile(String phoneNo) throws PizzaException {
		
		 if(!phoneNo.matches("[0-9]{10}")){
	 	    	throw new PizzaException();
	 	    }
		return true;
		
	}
	
}
